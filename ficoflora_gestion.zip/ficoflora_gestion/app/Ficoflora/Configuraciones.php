<?php
/**
 * Created by PhpStorm.
 * User: Lupita
 * Date: 08/08/2015
 * Time: 11:54
 */

namespace App\Ficoflora;


class Configuraciones {

    public static function getId()
    {

    }

}