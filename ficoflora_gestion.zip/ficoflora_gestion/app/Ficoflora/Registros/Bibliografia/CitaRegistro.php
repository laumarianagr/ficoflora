<?php
/**
 * Created by PhpStorm.
 * User: maria-pinzon
 * Date: 08/07/2015
 * Time: 5:27
 */

namespace App\Ficoflora\Registros\Bibliografia;


class CitaRegistro {

}