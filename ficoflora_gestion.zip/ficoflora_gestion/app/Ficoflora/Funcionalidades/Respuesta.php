<?php
/**
 * Created by PhpStorm.
 * User: Lupita
 * Date: 31/07/2015
 * Time: 21:12
 */

namespace App\Ficoflora\Funcionalidades;


class Respuesta {

    public $error;
    public $log;
    public $existe=true;
}